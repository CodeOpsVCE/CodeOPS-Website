import jwt from "jsonwebtoken";

export function requireAuth(req, res, next) {
  const token = req.cookies?.codeops_token;

  if (!token) {
    return res.status(401).json({ message: "Authentication required" });
  }

  try {
    req.admin = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ message: "Invalid or expired session" });
  }
}
