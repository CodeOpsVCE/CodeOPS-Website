import mongoose from "mongoose";

const eventSchema = new mongoose.Schema(
  {
    code: { type: String, required: true, unique: true, trim: true },
    title: { type: String, required: true, trim: true },
    poster: { type: String, default: "" },
    description: { type: String, required: true, trim: true },
    venue: { type: String, required: true, trim: true },
    deadline: { type: Date, required: true },
    status: { type: String, enum: ["OPEN", "ONGOING", "CLOSED"], default: "OPEN", trim: true },
    ongoingSince: { type: Date, default: null },
    registerUrl: { type: String, default: "" },
  },
  { timestamps: true }
);

export default mongoose.model("Event", eventSchema);
