export const DIVISIONS = [
  "Artificial Intelligence", "Competitive Programming", "Web Development",
  "Cyber Security", "App Development", "Design", "Media", "Events", "Core Committee",
];

export const STATUS_COLORS = {
  Online: "#00FF88",
  Training: "#00D9FF",
  Debugging: "#FFD400",
  Deploying: "#00D9FF",
  "On Mission": "#FF3B3B",
  Offline: "#5a5a5a",
};

export const agents = [
  {
    id: "AGT-001", name: "Rehan Iqbal",
    department: "Cyber Security", position: "S-Class Cyber Phantom", language: "Python", github: "#", linkedin: "#", portfolio: "#", photo: "https://placehold.co/200x200/050505/00FF88?text=AGT-001",
  },
  {
    id: "AGT-002", name: "Ananya Rao",
    department: "Competitive Programming", position: "A-Class Elite Agent", language: "C++", github: "#", linkedin: "#", portfolio: "#", photo: "https://placehold.co/200x200/050505/00D9FF?text=AGT-002",
  },
  {
    id: "AGT-003", name: "Kiran Vellanki",
    department: "Web Development", position: "B-Class Specialist", language: "TypeScript", github: "#", linkedin: "#", portfolio: "#", photo: "https://placehold.co/200x200/050505/00FF88?text=AGT-003",
  },
  {
    id: "AGT-004", name: "Sneha Patil",
    department: "Artificial Intelligence", position: "C-Class Operator", language: "Python", github: "#", linkedin: "#", portfolio: "#", photo: "https://placehold.co/200x200/050505/00D9FF?text=AGT-004",
  },
  {
    id: "AGT-005", name: "Devraj Sen",
    department: "Cyber Security", position: "Ω-Class Command Elite", language: "Rust", github: "#", linkedin: "#", portfolio: "#", photo: "https://placehold.co/200x200/050505/FF3B3B?text=AGT-005",
  },
  {
    id: "AGT-006", name: "Meher Chawla",
    department: "Design", position: "D-Class Recruit", language: "Figma / CSS", github: "#", linkedin: "#", portfolio: "#", photo: "https://placehold.co/200x200/050505/00FF88?text=AGT-006",
  },
  {
    id: "AGT-007", name: "Yashwanth Reddy",
    department: "App Development", position: "A-Class Elite Agent", language: "Kotlin", github: "#", linkedin: "#", portfolio: "#", photo: "https://placehold.co/200x200/050505/00D9FF?text=AGT-007",
  },
  {
    id: "AGT-008", name: "Ishita Bose",
    department: "Core Committee", position: "S-Class Cyber Phantom", language: "Go", github: "#", linkedin: "#", portfolio: "#", photo: "https://placehold.co/200x200/050505/FF3B3B?text=AGT-008",
  },
];